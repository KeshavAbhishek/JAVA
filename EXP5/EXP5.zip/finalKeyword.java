public class finalKeyword {
    public static void main(String[] args) {
        final float pi = 3.14f;

        pi = 10.15f;
    }
}
